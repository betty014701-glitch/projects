"""시각화 계층: Altair 차트 (Streamlit 설치 시 함께 설치됨)"""
from __future__ import annotations

import altair as alt
import pandas as pd

from .data import PART_COLORS, PARTS, WEEKDAYS

FONT = "Pretendard, 'Malgun Gothic', 'Apple SD Gothic Neo', sans-serif"
PRIMARY = "#4C6EF5"
PART_SCALE = alt.Scale(domain=list(PART_COLORS), range=list(PART_COLORS.values()))


def _finish(chart, height: int = 280):
    """모든 차트에 공통 스타일 적용"""
    return (chart.properties(height=height)
            .configure(font=FONT)
            .configure_view(strokeWidth=0)
            .configure_axis(labelColor="#6B7280", titleColor="#6B7280", gridColor="#EEF0F4",
                            domainColor="#E5E7EB", tickColor="#E5E7EB", labelFontSize=11, titleFontSize=11)
            .configure_legend(labelColor="#374151", titleColor="#6B7280", orient="bottom", labelFontSize=12))


def calendar_heatmap(frame: pd.DataFrame):
    week_order = list(dict.fromkeys(frame["week"]))
    chart = alt.Chart(frame).mark_rect(cornerRadius=4, stroke="white", strokeWidth=3).encode(
        x=alt.X("week:O", sort=week_order, title=None, axis=alt.Axis(labelAngle=0, ticks=False, domain=False)),
        y=alt.Y("weekday:O", sort=WEEKDAYS, title=None, axis=alt.Axis(ticks=False, domain=False)),
        color=alt.condition("datum.volume > 0",
                            alt.Color("volume:Q", scale=alt.Scale(scheme="blues", domainMin=0), legend=None),
                            alt.value("#EEF1F6")),
        tooltip=[alt.Tooltip("date:N", title="날짜"), alt.Tooltip("parts:N", title="부위"),
                 alt.Tooltip("volume:Q", title="볼륨(kg)", format=",.0f")],
    )
    return _finish(chart, 230)


def part_donut(df: pd.DataFrame):
    """부위별 세트 비중 도넛 차트"""
    d = df.groupby("부위")["세트"].sum().reindex(PARTS).dropna().reset_index()
    d.columns = ["part", "sets"]
    d["share"] = d["sets"] / d["sets"].sum()
    arcs = alt.Chart(d).mark_arc(innerRadius=72, outerRadius=118, cornerRadius=4, padAngle=0.015).encode(
        theta=alt.Theta("sets:Q", stack=True),
        color=alt.Color("part:N", scale=PART_SCALE, sort=PARTS, title=None),
        order=alt.Order("part:N", sort="ascending"),
        tooltip=[alt.Tooltip("part:N", title="부위"), alt.Tooltip("sets:Q", title="세트 수"),
                 alt.Tooltip("share:Q", title="비중", format=".0%")],
    )
    center = alt.Chart(pd.DataFrame({"t": [f"{int(d['sets'].sum()):,}세트"]})).mark_text(
        fontSize=20, fontWeight="bold", color="#1F2937").encode(text="t:N")
    return _finish(alt.layer(arcs, center), 300)


def part_volume_bar(df: pd.DataFrame):
    d = df.groupby("부위")["볼륨"].sum().reindex(PARTS).dropna().reset_index()
    d.columns = ["part", "volume"]
    chart = alt.Chart(d).mark_bar(cornerRadiusTopLeft=6, cornerRadiusTopRight=6, size=38).encode(
        x=alt.X("part:N", sort=PARTS, title=None, axis=alt.Axis(labelAngle=0)),
        y=alt.Y("volume:Q", title="누적 볼륨 (kg)", axis=alt.Axis(format="~s")),
        color=alt.Color("part:N", scale=PART_SCALE, legend=None),
        tooltip=[alt.Tooltip("part:N", title="부위"), alt.Tooltip("volume:Q", title="볼륨(kg)", format=",.0f")],
    )
    return _finish(chart, 300)


def weekly_days_bar(weekly: pd.DataFrame, goal: int):
    d = weekly.rename(columns={"주차": "week", "운동일수": "days"}).copy()
    d["label"] = pd.to_datetime(d["week"]).dt.strftime("%m/%d")
    d["met"] = d["days"].ge(goal).map({True: "목표 달성", False: "미달성"})
    order = list(d["label"])
    bars = alt.Chart(d).mark_bar(cornerRadiusTopLeft=5, cornerRadiusTopRight=5).encode(
        x=alt.X("label:O", sort=order, title="주 시작일", axis=alt.Axis(labelAngle=0)),
        y=alt.Y("days:Q", title="운동일수", scale=alt.Scale(domain=[0, 7]), axis=alt.Axis(tickMinStep=1)),
        color=alt.Color("met:N", title=None,
                        scale=alt.Scale(domain=["목표 달성", "미달성"], range=[PRIMARY, "#C5CEE0"])),
        tooltip=[alt.Tooltip("label:N", title="주 시작일"), alt.Tooltip("days:Q", title="운동일수")],
    )
    rule = alt.Chart(pd.DataFrame({"y": [goal]})).mark_rule(color="#F03E3E", strokeDash=[6, 4], size=2).encode(y="y:Q")
    text = alt.Chart(pd.DataFrame({"y": [goal], "t": [f"목표 {goal}일"]})).mark_text(
        align="left", dx=4, dy=-8, color="#F03E3E", fontWeight="bold").encode(y="y:Q", text="t:N", x=alt.value(0))
    return _finish(alt.layer(bars, rule, text), 290)


def weekly_volume_area(weekly: pd.DataFrame):
    d = weekly.rename(columns={"주차": "week", "볼륨": "volume"}).copy()
    d["week"] = pd.to_datetime(d["week"])
    base = alt.Chart(d).encode(x=alt.X("week:T", title="주 시작일", axis=alt.Axis(format="%m/%d")))
    area = base.mark_area(
        line={"color": PRIMARY, "strokeWidth": 2.5}, interpolate="monotone",
        color=alt.Gradient(gradient="linear", x1=1, x2=1, y1=1, y2=0,
                           stops=[alt.GradientStop(color="rgba(76,110,245,0.03)", offset=0),
                                  alt.GradientStop(color="rgba(76,110,245,0.35)", offset=1)]),
    ).encode(y=alt.Y("volume:Q", title="주간 볼륨 (kg)", axis=alt.Axis(format="~s")))
    points = base.mark_circle(size=55, color=PRIMARY).encode(
        y="volume:Q",
        tooltip=[alt.Tooltip("week:T", title="주 시작일", format="%Y-%m-%d"),
                 alt.Tooltip("volume:Q", title="볼륨(kg)", format=",.0f")])
    return _finish(alt.layer(area, points), 290)


def growth_line(sessions: pd.DataFrame, target: float | None = None):
    """운동별 최고 무게 & 추정 1RM 추이"""
    d = sessions[["날짜", "최고무게", "추정1RM"]].rename(columns={"날짜": "date", "최고무게": "최고 무게", "추정1RM": "추정 1RM"})
    d["date"] = pd.to_datetime(d["date"])
    long = d.melt("date", var_name="metric", value_name="kg")
    lines = alt.Chart(long).mark_line(point=alt.OverlayMarkDef(size=45, filled=True), strokeWidth=2.5,
                                      interpolate="monotone").encode(
        x=alt.X("date:T", title=None, axis=alt.Axis(format="%m/%d")),
        y=alt.Y("kg:Q", title="kg", scale=alt.Scale(zero=False)),
        color=alt.Color("metric:N", title=None,
                        scale=alt.Scale(domain=["최고 무게", "추정 1RM"], range=[PRIMARY, "#20C997"])),
        strokeDash=alt.StrokeDash("metric:N", legend=None,
                                  scale=alt.Scale(domain=["최고 무게", "추정 1RM"], range=[[1, 0], [5, 3]])),
        tooltip=[alt.Tooltip("date:T", title="날짜", format="%Y-%m-%d"),
                 alt.Tooltip("metric:N", title="지표"), alt.Tooltip("kg:Q", title="kg", format=".1f")],
    )
    layers = [lines]
    if target:
        layers.append(alt.Chart(pd.DataFrame({"y": [target]})).mark_rule(
            color="#F03E3E", strokeDash=[6, 4], size=2).encode(y="y:Q"))
        layers.append(alt.Chart(pd.DataFrame({"y": [target], "t": [f"목표 {target:g}kg"]})).mark_text(
            align="left", dx=4, dy=-8, color="#F03E3E", fontWeight="bold").encode(y="y:Q", text="t:N", x=alt.value(0)))
    return _finish(alt.layer(*layers), 320)


def sparkline(sessions: pd.DataFrame):
    """최근 기록 미니 차트 (무게, 맨몸 운동이면 횟수)"""
    bw = bool(sessions["맨몸"].iloc[0])
    d = sessions[["날짜", "기록값"]].rename(columns={"날짜": "date", "기록값": "v"}).copy()
    d["date"] = pd.to_datetime(d["date"])
    chart = alt.Chart(d).mark_line(point=True, color=PRIMARY, strokeWidth=2, interpolate="monotone").encode(
        x=alt.X("date:T", title=None, axis=alt.Axis(format="%m/%d", labelFontSize=10, grid=False)),
        y=alt.Y("v:Q", title=None, scale=alt.Scale(zero=False), axis=alt.Axis(labelFontSize=10)),
        tooltip=[alt.Tooltip("date:T", title="날짜", format="%Y-%m-%d"),
                 alt.Tooltip("v:Q", title="최고 횟수" if bw else "최고 무게(kg)")],
    )
    return _finish(chart, 150)


def reps_line(sessions: pd.DataFrame):
    """맨몸 운동의 최고 횟수 추이"""
    d = sessions[["날짜", "최고횟수"]].rename(columns={"날짜": "date", "최고횟수": "reps"}).copy()
    d["date"] = pd.to_datetime(d["date"])
    chart = alt.Chart(d).mark_line(point=alt.OverlayMarkDef(size=45, filled=True), strokeWidth=2.5,
                                   color="#20C997", interpolate="monotone").encode(
        x=alt.X("date:T", title=None, axis=alt.Axis(format="%m/%d")),
        y=alt.Y("reps:Q", title="세트당 최고 횟수", scale=alt.Scale(zero=False), axis=alt.Axis(tickMinStep=1)),
        tooltip=[alt.Tooltip("date:T", title="날짜", format="%Y-%m-%d"), alt.Tooltip("reps:Q", title="최고 횟수")],
    )
    return _finish(chart, 320)


def weekday_bar(df: pd.DataFrame):
    days = pd.Series(pd.to_datetime(pd.Series(df["날짜"].unique())).dt.weekday)
    d = days.map(lambda i: WEEKDAYS[i]).value_counts().reindex(WEEKDAYS, fill_value=0).reset_index()
    d.columns = ["weekday", "count"]
    chart = alt.Chart(d).mark_bar(cornerRadiusTopLeft=6, cornerRadiusTopRight=6, size=30, color=PRIMARY).encode(
        x=alt.X("weekday:O", sort=WEEKDAYS, title=None, axis=alt.Axis(labelAngle=0)),
        y=alt.Y("count:Q", title="운동한 날 수", axis=alt.Axis(tickMinStep=1)),
        tooltip=[alt.Tooltip("weekday:N", title="요일"), alt.Tooltip("count:Q", title="운동한 날")],
    )
    return _finish(chart, 280)


def part_weekday_heatmap(df: pd.DataFrame):
    d = df.drop_duplicates(["날짜", "부위"]).copy()
    d["weekday"] = pd.to_datetime(d["날짜"]).dt.weekday.map(lambda i: WEEKDAYS[i])
    d = d.groupby(["부위", "weekday"]).size().reset_index(name="n").rename(columns={"부위": "part"})
    base = alt.Chart(d).encode(
        x=alt.X("weekday:O", sort=WEEKDAYS, title=None, axis=alt.Axis(labelAngle=0)),
        y=alt.Y("part:O", sort=PARTS, title=None),
    )
    rect = base.mark_rect(cornerRadius=4, stroke="white", strokeWidth=2).encode(
        color=alt.Color("n:Q", scale=alt.Scale(scheme="purples"), legend=None),
        tooltip=[alt.Tooltip("part:N", title="부위"), alt.Tooltip("weekday:N", title="요일"),
                 alt.Tooltip("n:Q", title="횟수")])
    text = base.mark_text(fontSize=12, fontWeight="bold").encode(
        text="n:Q", color=alt.condition("datum.n >= 4", alt.value("white"), alt.value("#374151")))
    return _finish(alt.layer(rect, text), 280)

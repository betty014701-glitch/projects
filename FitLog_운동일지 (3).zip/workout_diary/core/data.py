"""데이터 계층: 파일 입출력, 파생 지표 계산, 분석 함수

- workout_log.csv : 날짜, 운동명, 세트, 횟수, 무게(kg), 메모
- exercises.csv   : 운동명, 부위, 구분, 장비   (운동명으로 기록과 연결)
- settings.json   : weekly_goal, targets
"""
from __future__ import annotations

import json
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
LOG_FILE = DATA_DIR / "workout_log.csv"
EX_FILE = DATA_DIR / "exercises.csv"
SETTINGS_FILE = DATA_DIR / "settings.json"

LOG_COLS = ["날짜", "운동명", "세트", "횟수", "무게(kg)", "메모"]
EX_COLS = ["운동명", "부위", "구분", "장비"]
PARTS = ["가슴", "등", "하체", "어깨", "팔", "기타"]
PART_COLORS = {
    "가슴": "#4C6EF5", "등": "#12B886", "하체": "#F03E3E",
    "어깨": "#F59F00", "팔": "#7950F2", "기타": "#868E96",
}
WEEKDAYS = ["월", "화", "수", "목", "금", "토", "일"]
DEFAULT_SETTINGS = {"weekly_goal": 4, "targets": {}}


# =====================================================================
# 파일 입출력 (파일 수정 시각을 캐시 키로 사용 → 저장하면 자동 갱신)
# =====================================================================
def _mtime(path: Path) -> float:
    return path.stat().st_mtime if path.exists() else 0.0


@st.cache_data(show_spinner=False)
def _read_csv(path_str: str, mtime: float, columns: tuple) -> pd.DataFrame:
    path = Path(path_str)
    if not path.exists():
        return pd.DataFrame(columns=list(columns))
    return pd.read_csv(path, encoding="utf-8-sig")


def load_exercises() -> pd.DataFrame:
    ex = _read_csv(str(EX_FILE), _mtime(EX_FILE), tuple(EX_COLS)).copy()
    return ex.dropna(subset=["운동명"]).drop_duplicates("운동명").reset_index(drop=True)


def load_raw_log() -> pd.DataFrame:
    return _read_csv(str(LOG_FILE), _mtime(LOG_FILE), tuple(LOG_COLS)).copy()


def load_log() -> pd.DataFrame:
    """기록 + 운동 마스터를 합치고 파생 지표(볼륨, 추정 1RM)를 붙인 분석용 데이터"""
    return enrich(load_raw_log(), load_exercises())


def enrich(log: pd.DataFrame, ex: pd.DataFrame) -> pd.DataFrame:
    extra = ["부위", "구분", "장비", "볼륨", "추정1RM"]
    if log.empty:
        return pd.DataFrame(columns=LOG_COLS + extra)
    df = log.copy()  # 인덱스 = CSV 행 번호 (수정·삭제 시 사용)
    df["날짜"] = pd.to_datetime(df["날짜"]).dt.date
    df["메모"] = df["메모"].fillna("").astype(str)
    df["세트"] = pd.to_numeric(df["세트"], errors="coerce").fillna(0).astype(int)
    df["횟수"] = pd.to_numeric(df["횟수"], errors="coerce").fillna(0).astype(int)
    df["무게(kg)"] = pd.to_numeric(df["무게(kg)"], errors="coerce").fillna(0.0).astype(float)
    info = ex.set_index("운동명")
    df["부위"] = df["운동명"].map(info["부위"]).fillna("기타")
    df["구분"] = df["운동명"].map(info["구분"]).fillna("-")
    df["장비"] = df["운동명"].map(info["장비"]).fillna("-")
    df["볼륨"] = df["세트"] * df["횟수"] * df["무게(kg)"]  # 맨몸 운동은 0 (횟수로 따로 추적)
    df["추정1RM"] = estimate_1rm(df["무게(kg)"], df["횟수"])
    return df


def save_log(df: pd.DataFrame) -> None:
    DATA_DIR.mkdir(exist_ok=True)
    out = df[LOG_COLS].copy()
    out["날짜"] = pd.to_datetime(out["날짜"]).dt.strftime("%Y-%m-%d")
    out["메모"] = out["메모"].fillna("")
    out = out.sort_values("날짜", kind="stable")
    out.to_csv(LOG_FILE, index=False, encoding="utf-8-sig")


def append_record(record: dict) -> None:
    raw = load_raw_log()
    save_log(pd.concat([raw, pd.DataFrame([record])], ignore_index=True))


def save_exercises(ex: pd.DataFrame) -> None:
    DATA_DIR.mkdir(exist_ok=True)
    ex = ex.dropna(subset=["운동명"])
    ex = ex[ex["운동명"].astype(str).str.strip() != ""].drop_duplicates("운동명")
    ex[EX_COLS].to_csv(EX_FILE, index=False, encoding="utf-8-sig")


def add_exercise(name: str, part: str, kind: str, equip: str = "-") -> None:
    ex = load_exercises()
    if name not in set(ex["운동명"]):
        save_exercises(pd.concat([ex, pd.DataFrame([[name, part, kind, equip]], columns=EX_COLS)]))


def load_settings() -> dict:
    if not SETTINGS_FILE.exists():
        return dict(DEFAULT_SETTINGS)
    data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
    return {**DEFAULT_SETTINGS, **data}


def save_settings(settings: dict) -> None:
    DATA_DIR.mkdir(exist_ok=True)
    SETTINGS_FILE.write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8")


# =====================================================================
# 계산 함수
# =====================================================================
def estimate_1rm(weight, reps):
    """Epley 공식: 1RM = 무게 × (1 + 횟수/30). 1회 수행이면 그 무게가 곧 1RM"""
    weight = np.asarray(weight, dtype=float)
    reps = np.asarray(reps, dtype=float)
    return np.round(np.where(reps <= 1, weight, weight * (1 + reps / 30)), 1)


def week_start(d: date) -> date:
    return d - timedelta(days=d.weekday())


def filter_period(df: pd.DataFrame, weeks: int | None) -> pd.DataFrame:
    if df.empty or weeks is None:
        return df
    since = week_start(date.today()) - timedelta(weeks=weeks - 1)
    return df[df["날짜"] >= since]


def weekly_summary(df: pd.DataFrame) -> pd.DataFrame:
    """주(월요일 시작)별 운동일수·볼륨. 운동하지 않은 주도 0으로 채운다."""
    if df.empty:
        return pd.DataFrame(columns=["주차", "운동일수", "볼륨"])
    days = df.groupby("날짜")["볼륨"].sum().reset_index()
    days["주차"] = days["날짜"].map(week_start)
    w = days.groupby("주차").agg(운동일수=("날짜", "nunique"), 볼륨=("볼륨", "sum"))
    weeks = pd.date_range(min(w.index), week_start(date.today()), freq="7D").date
    return w.reindex(weeks, fill_value=0).rename_axis("주차").reset_index()


def volume_until(df: pd.DataFrame, start: date, end: date) -> float:
    """start~end(포함) 기간의 총 볼륨"""
    if df.empty:
        return 0.0
    return float(df.loc[(df["날짜"] >= start) & (df["날짜"] <= end), "볼륨"].sum())


def goal_streak(weekly: pd.DataFrame, goal: int) -> int:
    """주간 목표를 연속으로 달성한 주 수 (진행 중인 이번 주는 달성했을 때만 포함)"""
    streak = 0
    rows = weekly.sort_values("주차", ascending=False).reset_index(drop=True)
    for i, row in rows.iterrows():
        if row["운동일수"] >= goal:
            streak += 1
        elif i == 0 and row["주차"] == week_start(date.today()):
            continue  # 이번 주는 아직 진행 중
        else:
            break
    return streak


def is_bodyweight(rows: pd.DataFrame) -> bool:
    """무게 없이(0kg) 기록된 맨몸 운동인지"""
    return not rows.empty and float(rows["무게(kg)"].max()) == 0.0


def session_max(df: pd.DataFrame) -> pd.DataFrame:
    """운동명·날짜별 최고 무게, 최고 추정 1RM, 최고 횟수"""
    s = (df.groupby(["운동명", "날짜"], as_index=False)
           .agg(부위=("부위", "first"), 최고무게=("무게(kg)", "max"), 추정1RM=("추정1RM", "max"),
                최고횟수=("횟수", "max"), 총세트=("세트", "sum"), 볼륨=("볼륨", "sum")))
    bw = s.groupby("운동명")["최고무게"].transform("max") == 0
    s["맨몸"] = bw
    s["기록값"] = np.where(bw, s["최고횟수"], s["최고무게"])  # 성장 판단 기준: 무게, 맨몸이면 횟수
    return s


def fmt_record(value: float, bodyweight: bool) -> str:
    return f"{value:g}회" if bodyweight else f"{value:g} kg"


def pr_events(df: pd.DataFrame) -> pd.DataFrame:
    """최고 무게(PR)를 갱신한 순간들"""
    cols = ["날짜", "부위", "운동명", "이전", "신기록", "향상"]
    if df.empty:
        return pd.DataFrame(columns=cols)
    s = session_max(df).sort_values(["운동명", "날짜"])
    s["이전최고"] = s.groupby("운동명")["기록값"].transform(lambda x: x.cummax().shift())
    ev = s[s["이전최고"].notna() & (s["기록값"] > s["이전최고"])].copy()
    if ev.empty:
        return pd.DataFrame(columns=cols)
    ev["이전"] = [fmt_record(v, b) for v, b in zip(ev["이전최고"], ev["맨몸"])]
    ev["신기록"] = [fmt_record(v, b) for v, b in zip(ev["기록값"], ev["맨몸"])]
    ev["향상"] = ["+" + fmt_record(n - p, b) for n, p, b in zip(ev["기록값"], ev["이전최고"], ev["맨몸"])]
    return ev.sort_values("날짜", ascending=False)[cols]


def personal_records(df: pd.DataFrame, targets: dict | None = None) -> pd.DataFrame:
    """운동별 최고 기록표 (+ 목표 달성률)"""
    if df.empty:
        return pd.DataFrame()
    bw = df.groupby("운동명")["무게(kg)"].transform("max") == 0
    key = np.where(bw, df["횟수"], df["무게(kg)"])  # 맨몸 운동은 최고 횟수 기준
    idx = pd.Series(key, index=df.index).groupby(df["운동명"]).idxmax()
    best = df.loc[idx, ["부위", "운동명", "장비", "무게(kg)", "횟수", "날짜"]]
    best = best.rename(columns={"무게(kg)": "최고무게", "날짜": "달성일"})
    best["최고기록"] = [fmt_record(r, True) if w == 0 else f"{w:g} kg × {r}회"
                        for w, r in zip(best["최고무게"], best["횟수"])]
    best["최고추정1RM"] = best["운동명"].map(df.groupby("운동명")["추정1RM"].max()).replace(0, np.nan)
    best["운동횟수"] = best["운동명"].map(df.groupby("운동명")["날짜"].nunique())
    targets = targets or {}
    best["목표무게"] = best["운동명"].map(targets)
    best["달성률"] = (best["최고무게"] / best["목표무게"]).clip(upper=1.0)
    order = {p: i for i, p in enumerate(PARTS)}
    return best.sort_values(["부위", "최고무게"], key=lambda c: c.map(order) if c.name == "부위" else -c)


def heatmap_frame(df: pd.DataFrame, weeks: int = 16) -> pd.DataFrame:
    """최근 N주 달력 히트맵용 데이터 (차트용이라 영문 컬럼 사용)"""
    today = date.today()
    start = week_start(today) - timedelta(weeks=weeks - 1)
    vol = df.groupby("날짜")["볼륨"].sum() if not df.empty else pd.Series(dtype=float)
    parts = df.groupby("날짜")["부위"].agg(lambda s: ", ".join(dict.fromkeys(s))) if not df.empty else pd.Series(dtype=str)
    rows = []
    for i in range((today - start).days + 1):
        d = start + timedelta(days=i)
        rows.append({
            "date": d.isoformat(),
            "week": week_start(d).strftime("%m/%d"),
            "weekday": WEEKDAYS[d.weekday()],
            "volume": float(vol.get(d, 0.0)),
            "parts": parts.get(d, "휴식"),
        })
    return pd.DataFrame(rows)


def insights(df: pd.DataFrame, weekly: pd.DataFrame, goal: int) -> list[tuple[str, str]]:
    """데이터를 바탕으로 자동 생성하는 분석 코멘트 (아이콘, 문장)"""
    out: list[tuple[str, str]] = []
    if df.empty:
        return out
    today = date.today()

    # 1) 마지막 운동 이후 경과일
    gap = (today - df["날짜"].max()).days
    if gap >= 3:
        out.append(("⏰", f"마지막 운동 후 <b>{gap}일</b>이 지났어요. 가볍게라도 다시 시작해 봐요."))

    # 2) 이번 주 목표 진행 상황 + 지난주(완료된 주) 볼륨 변화
    if not weekly.empty:
        done = int(weekly.iloc[-1]["운동일수"])
        if done >= goal:
            out.append(("🎯", f"이번 주 목표 <b>{goal}일</b>을 달성했어요! 지금 페이스를 유지해요."))
        else:
            out.append(("🗓️", f"이번 주 <b>{done}일</b> 운동했어요. 목표까지 <b>{goal - done}일</b> 남았어요."))
    if len(weekly) >= 3:
        last_v, prev_v = weekly.iloc[-2]["볼륨"], weekly.iloc[-3]["볼륨"]
        if prev_v > 0:
            rate = (last_v - prev_v) / prev_v * 100
            if abs(rate) < 3:
                out.append(("➖", "지난주 총 볼륨은 그 전 주와 <b>비슷했어요</b>. 꾸준함이 유지되고 있어요."))
            else:
                icon = "📈" if rate > 0 else "📉"
                out.append((icon, f"지난주 총 볼륨은 그 전 주보다 <b>{abs(rate):.0f}%</b> {'늘었어요' if rate > 0 else '줄었어요'}."))

    # 3) 최근 4주 부위 밸런스
    recent = filter_period(df, 4)
    if not recent.empty:
        share = recent.groupby("부위")["날짜"].nunique()
        share = share.reindex([p for p in PARTS if p != "기타"], fill_value=0)
        share = share / share.sum()
        weak = share.idxmin()
        if share.min() < 0.15:
            out.append(("⚖️", f"최근 4주 <b>{weak}</b> 운동 비중이 <b>{share.min() * 100:.0f}%</b>로 낮아요. 균형을 맞춰 보세요."))

    # 4) 가장 많이 성장한 운동 (복합 운동의 추정 1RM 기준, 4회 이상 수행)
    #    가벼운 고립 운동은 2.5kg만 올라도 %가 크게 튀므로 제외
    s = session_max(df).sort_values("날짜")
    compound = set(df.loc[df["구분"] == "복합", "운동명"])
    growth = []
    for name, g in s[s["운동명"].isin(compound) & ~s["맨몸"]].groupby("운동명"):
        if len(g) >= 4:
            first, best = g["추정1RM"].iloc[:2].mean(), g["추정1RM"].iloc[-3:].mean()
            if first > 0:
                growth.append((name, (best - first) / first * 100))
    if growth:
        name, rate = max(growth, key=lambda x: x[1])
        out.append(("🚀", f"가장 많이 성장한 운동은 <b>{name}</b>! 추정 1RM이 <b>{rate:+.0f}%</b> 늘었어요."))
    bw = s[s["맨몸"]]
    for name, g in bw.groupby("운동명"):
        if len(g) >= 4:
            out.append(("🤸", f"맨몸 운동 <b>{name}</b>는 최고 <b>{int(g['최고횟수'].iloc[:2].mean())}회 → "
                              f"{int(g['최고횟수'].iloc[-3:].max())}회</b>로 늘었어요."))
            break

    # 5) 최근 PR
    ev = pr_events(df)
    recent_pr = ev[ev["날짜"] >= today - timedelta(days=14)]
    if not recent_pr.empty:
        out.append(("🏆", f"최근 2주 동안 PR을 <b>{len(recent_pr)}번</b> 갱신했어요."))

    # 6) 가장 꾸준한 요일
    wd = pd.Series([d.weekday() for d in df["날짜"].unique()]).value_counts()
    out.append(("📅", f"주로 <b>{WEEKDAYS[wd.idxmax()]}요일</b>에 운동해요."))
    return out

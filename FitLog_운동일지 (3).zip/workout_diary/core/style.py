"""디자인 계층: 공통 CSS와 UI 컴포넌트"""
from html import escape

import streamlit as st

CSS = """
<style>
@import url('https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.min.css');
html, body, .stApp, .stMarkdown, p, li, label, input, textarea, h1, h2, h3, h4,
[data-testid="stMetricValue"], [data-testid="stMetricLabel"], [data-testid="stMetricDelta"] {
  font-family: 'Pretendard', 'Malgun Gothic', 'Apple SD Gothic Neo', sans-serif;
}
.block-container { padding-top: 2.2rem; padding-bottom: 3rem; max-width: 1200px; }
#MainMenu, footer { visibility: hidden; }

/* 상단 헤더 배너 */
.hero { background: linear-gradient(135deg, #4C6EF5 0%, #7950F2 100%); border-radius: 18px;
        padding: 24px 28px; margin-bottom: 22px; box-shadow: 0 8px 24px rgba(76,110,245,.18); }
.hero .eyebrow { color: rgba(255,255,255,.75); font-size: .8rem; font-weight: 600; letter-spacing: .08em; }
.hero h1 { color: #fff; font-size: 1.75rem; font-weight: 800; margin: 4px 0 0; padding: 0; }
.hero p { color: rgba(255,255,255,.88); margin: 6px 0 0; font-size: .95rem; }

/* KPI 카드 */
[data-testid="stMetric"] { background: #fff; border: 1px solid #E9ECF2; border-radius: 14px;
  padding: 16px 18px; box-shadow: 0 1px 3px rgba(16,24,40,.05); }
[data-testid="stMetricLabel"] p { font-size: .85rem; color: #6B7280; font-weight: 600; }
[data-testid="stMetricValue"] { font-size: 1.65rem; font-weight: 800; color: #111827; }

/* 섹션 제목 */
.section { font-size: 1.08rem; font-weight: 750; color: #111827; margin: 8px 0 10px;
           display: flex; align-items: center; gap: 8px; }
.section .sub { font-size: .8rem; font-weight: 500; color: #9CA3AF; }

/* 인사이트 카드 */
.insight { display: flex; gap: 10px; align-items: flex-start; background: #F5F7FB;
           border-radius: 12px; padding: 11px 14px; margin-bottom: 8px; font-size: .92rem; color: #374151; line-height: 1.5; }
.insight .ic { font-size: 1.1rem; line-height: 1.4; }
.insight b { color: #4C6EF5; }

/* 정보 카드 */
.info-card { background: #fff; border: 1px solid #E9ECF2; border-radius: 14px; padding: 16px 18px; margin-bottom: 10px; }
.info-card .label { color: #6B7280; font-size: .8rem; font-weight: 600; }
.info-card .value { color: #111827; font-size: 1.25rem; font-weight: 800; margin-top: 2px; }
.info-card .hint { color: #9CA3AF; font-size: .8rem; margin-top: 2px; }

.chip { display: inline-block; padding: 2px 10px; border-radius: 999px; font-size: .78rem;
        font-weight: 700; color: #fff; margin-right: 4px; }

/* 사이드바 */
[data-testid="stSidebar"] { background: #F8F9FC; border-right: 1px solid #EEF0F4; }
.side-brand { font-size: 1.25rem; font-weight: 800; color: #111827; margin: 4px 0 2px; }
.side-sub { color: #9CA3AF; font-size: .8rem; margin-bottom: 8px; }
.side-stat { font-size: .85rem; color: #4B5563; margin: 2px 0; }
</style>
"""


def apply_style() -> None:
    st.markdown(CSS, unsafe_allow_html=True)


def hero(title: str, subtitle: str, eyebrow: str = "MY WORKOUT DIARY") -> None:
    st.markdown(
        f'<div class="hero"><div class="eyebrow">{escape(eyebrow)}</div>'
        f'<h1>{escape(title)}</h1><p>{escape(subtitle)}</p></div>',
        unsafe_allow_html=True,
    )


def section(title: str, sub: str = "") -> None:
    sub_html = f'<span class="sub">{escape(sub)}</span>' if sub else ""
    st.markdown(f'<div class="section">{escape(title)} {sub_html}</div>', unsafe_allow_html=True)


def insight_list(items: list[tuple[str, str]]) -> None:
    """items의 문장은 앱 내부에서 만든 HTML(<b> 강조)이므로 그대로 출력"""
    html = "".join(f'<div class="insight"><span class="ic">{icon}</span><span>{text}</span></div>'
                   for icon, text in items)
    st.markdown(html, unsafe_allow_html=True)


def info_card(label: str, value: str, hint: str = "") -> None:
    st.markdown(
        f'<div class="info-card"><div class="label">{escape(label)}</div>'
        f'<div class="value">{escape(value)}</div><div class="hint">{escape(hint)}</div></div>',
        unsafe_allow_html=True,
    )


def chip(text: str, color: str) -> str:
    return f'<span class="chip" style="background:{color}">{escape(text)}</span>'

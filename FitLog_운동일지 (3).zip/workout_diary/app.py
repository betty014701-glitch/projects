"""💪 FitLog - 나의 운동일지 (Streamlit 미니 프로젝트)

실행 방법
    pip install -r requirements.txt
    streamlit run app.py

구성
    app.py          화면(페이지) 구성
    core/data.py    데이터 입출력 · 지표 계산 · 분석
    core/charts.py  Altair 차트
    core/style.py   디자인(CSS) · UI 컴포넌트
    data/           운동 기록, 운동 마스터, 설정 파일
"""
from datetime import date, timedelta

import pandas as pd
import streamlit as st

from core import charts as C
from core import data as D
from core import style as S

st.set_page_config(page_title="FitLog · 나의 운동일지", page_icon="💪", layout="wide")
S.apply_style()

PERIODS = {"최근 4주": 4, "최근 8주": 8, "최근 12주": 12, "전체 기간": None}


def show_chart(chart) -> None:
    """차트를 화면 너비에 맞춰 출력 (Streamlit 버전 차이 대응)"""
    try:
        st.altair_chart(chart, width="stretch")
    except TypeError:
        st.altair_chart(chart, use_container_width=True)


def empty_state() -> None:
    st.info("아직 운동 기록이 없어요. 왼쪽 메뉴의 **기록 추가**에서 첫 운동을 기록해 보세요!", icon="📝")


# =====================================================================
# 1. 대시보드
# =====================================================================
def page_dashboard():
    df, settings = D.load_log(), D.load_settings()
    goal = int(settings["weekly_goal"])
    today = date.today()
    S.hero("대시보드", f"{today:%Y년 %m월 %d일} · 이번 주 운동 현황과 나의 성장을 한눈에 확인하세요.")
    if df.empty:
        return empty_state()

    weekly = D.weekly_summary(df)
    this_w = weekly.iloc[-1]
    # 진행 중인 이번 주는 '지난주 같은 요일까지'와 비교해야 공정하다
    last_same = D.volume_until(df, D.week_start(today) - timedelta(days=7), today - timedelta(days=7))
    days_same = df[(df["날짜"] >= D.week_start(today) - timedelta(days=7)) & (df["날짜"] <= today - timedelta(days=7))]
    vol_delta = f"{(this_w['볼륨'] - last_same) / last_same * 100:+.0f}% (지난주 같은 요일까지 대비)" if last_same else None
    streak = D.goal_streak(weekly, goal)

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("이번 주 운동", f"{int(this_w['운동일수'])} / {goal}일",
              f"{int(this_w['운동일수']) - days_same['날짜'].nunique():+d}일 (지난주 같은 요일까지 대비)")
    c2.metric("이번 주 볼륨", f"{this_w['볼륨']:,.0f} kg", vol_delta)
    c3.metric("연속 목표 달성", f"{streak}주", help=f"주 {goal}일 이상 운동한 주가 연속된 횟수")
    c4.metric("누적 운동일", f"{df['날짜'].nunique()}일", f"{df['날짜'].min():%Y.%m.%d}부터", delta_color="off")

    rate = min(1.0, this_w["운동일수"] / goal)
    st.progress(rate, text=f"이번 주 목표 달성률 {rate * 100:.0f}%")
    st.write("")

    left, right = st.columns([1.75, 1], gap="large")
    with left:
        S.section("🗓️ 운동 캘린더", "최근 16주 · 색이 진할수록 볼륨이 높아요")
        show_chart(C.calendar_heatmap(D.heatmap_frame(df, 16)))
    with right:
        S.section("💡 오늘의 인사이트", "데이터 기반 자동 분석")
        S.insight_list(D.insights(df, weekly, goal))

    left, right = st.columns([1.2, 1], gap="large")
    with left:
        S.section("🏋️ 최근 운동")
        for d in sorted(df["날짜"].unique(), reverse=True)[:4]:
            day_df = df[df["날짜"] == d]
            parts = " · ".join(dict.fromkeys(day_df["부위"]))
            with st.expander(f"{d:%m/%d} ({D.WEEKDAYS[d.weekday()]})  |  {parts}  |  볼륨 {day_df['볼륨'].sum():,.0f} kg"):
                st.dataframe(day_df[["운동명", "세트", "횟수", "무게(kg)", "추정1RM", "메모"]], hide_index=True,
                             width="stretch",
                             column_config={"무게(kg)": st.column_config.NumberColumn(format="%.1f kg"),
                                            "추정1RM": st.column_config.NumberColumn("추정 1RM", format="%.1f kg")})
    with right:
        S.section("🏆 최근 PR 갱신")
        ev = D.pr_events(df).head(6)
        if ev.empty:
            st.caption("아직 갱신한 기록이 없어요.")
        else:
            st.dataframe(ev[["날짜", "운동명", "이전", "신기록", "향상"]], hide_index=True, width="stretch",
                         column_config={"날짜": st.column_config.DateColumn(format="MM/DD")})


# =====================================================================
# 2. 기록 추가
# =====================================================================
def page_record():
    S.hero("기록 추가", "오늘의 운동을 기록하면 지난 기록과 비교해 성장 여부를 바로 알려드려요.")
    if flash := st.session_state.pop("flash", None):
        st.success(flash["msg"], icon="✅")
        if flash.get("pr"):
            st.balloons()
            st.success(flash["pr"], icon="🏆")

    df, ex = D.load_log(), D.load_exercises()
    left, right = st.columns([1.15, 1], gap="large")

    with left:
        S.section("📝 운동 입력")
        with st.container(border=True):
            c1, c2 = st.columns(2)
            day = c1.date_input("날짜", value=date.today(), max_value=date.today())
            part = c2.selectbox("부위", D.PARTS)
            options = sorted(ex.loc[ex["부위"] == part, "운동명"]) + ["＋ 새 운동 추가"]
            name = st.selectbox("운동", options)
            is_new = name == "＋ 새 운동 추가"
            if is_new:
                n1, n2, n3 = st.columns([2, 1, 1])
                name = n1.text_input("새 운동 이름", placeholder="예: 힙 쓰러스트").strip()
                kind = n2.selectbox("구분", ["복합", "고립"])
                equip = n3.selectbox("장비", ["바벨", "덤벨", "머신", "케이블", "맨몸", "기타"])
            equip_now = equip if is_new else ex.set_index("운동명")["장비"].get(name, "-")
            bw_mode = equip_now == "맨몸"
            c3, c4, c5 = st.columns(3)
            sets = c3.number_input("세트", 1, 20, 1, help="피라미드·상승 세트는 세트마다 1세트씩 따로 기록하세요")
            reps = c4.number_input("횟수", 1, 100, 12)
            weight = c5.number_input("무게 (kg)", 0.0, 500.0, 0.0 if bw_mode else 40.0, step=2.5,
                                     help="맨몸 운동은 0으로 두세요 (횟수로 성장을 추적해요)")
            memo = st.text_input("메모 (선택)", placeholder="컨디션, 자세, 느낀 점 등")
            est = float(D.estimate_1rm([weight], [reps])[0])
            if weight > 0:
                st.caption(f"이번 기록 → 볼륨 **{sets * reps * weight:,.0f} kg** · 추정 1RM **{est:.1f} kg**")
            else:
                st.caption(f"이번 기록 → 맨몸 **{reps}회 × {sets}세트** (총 {sets * reps}회)")
            save = st.button("기록 저장", type="primary", width="stretch")

    hist = df[df["운동명"] == name] if name else df.iloc[0:0]
    with right:
        S.section("📊 이 운동의 지난 기록")
        if hist.empty:
            st.info("처음 기록하는 운동이에요. 오늘이 첫 기록이 됩니다!", icon="✨")
        else:
            bw_hist = D.is_bodyweight(hist)
            last_day = hist["날짜"].max()
            ld = hist[hist["날짜"] == last_day]
            top = ld.loc[ld["횟수"].idxmax()] if bw_hist else ld.loc[ld["무게(kg)"].idxmax()]
            sets_txt = f"{last_day:%m/%d} · 총 {ld['세트'].sum()}세트"
            if len(ld) > 1:
                sets_txt += f" · {ld['무게(kg)'].min():g}→{ld['무게(kg)'].max():g}kg"
            k1, k2 = st.columns(2)
            with k1:
                S.info_card("지난 기록 (최고 세트)",
                            f"{top['횟수']}회" if bw_hist else f"{top['무게(kg)']:g}kg × {top['횟수']}회", sets_txt)
            with k2:
                if bw_hist:
                    S.info_card("최고 횟수 (PR)", f"{hist['횟수'].max()}회", "맨몸 운동은 횟수로 기록해요")
                else:
                    S.info_card("최고 무게 (PR)", f"{hist['무게(kg)'].max():g} kg",
                                f"추정 1RM 최고 {hist['추정1RM'].max():.1f} kg")
            if bw_hist and reps > hist["횟수"].max():
                st.success(f"지금 입력한 횟수는 PR보다 **{reps - hist['횟수'].max()}회** 많아요! 🔥")
            elif not bw_hist and weight > hist["무게(kg)"].max():
                st.success(f"지금 입력한 무게는 PR보다 **{weight - hist['무게(kg)'].max():g}kg** 무거워요! 🔥")
            sessions = D.session_max(hist).sort_values("날짜").tail(12)
            if len(sessions) >= 2:
                show_chart(C.sparkline(sessions))

    if save:
        if not name:
            st.error("운동 이름을 입력해 주세요.")
        else:
            if is_new:
                D.add_exercise(name, part, kind, equip)
            D.append_record({"날짜": day.isoformat(), "운동명": name, "세트": int(sets), "횟수": int(reps),
                             "무게(kg)": float(weight), "메모": memo})
            what = f"{weight:g}kg × {reps}회" if weight > 0 else f"{reps}회"
            flash = {"msg": f"{name} {what} × {sets}세트 저장 완료!"}
            if not hist.empty and D.is_bodyweight(hist) and weight == 0 and reps > hist["횟수"].max():
                flash["pr"] = f"{name} 최고 횟수 갱신! {hist['횟수'].max()}회 → {reps}회"
            elif not hist.empty and not D.is_bodyweight(hist) and weight > hist["무게(kg)"].max():
                flash["pr"] = f"{name} 최고 기록 갱신! {hist['무게(kg)'].max():g}kg → {weight:g}kg"
            st.session_state["flash"] = flash
            st.rerun()

    today_df = df[df["날짜"] == date.today()]
    if not today_df.empty:
        S.section("✅ 오늘 기록한 운동", f"{len(today_df)}개 · 볼륨 {today_df['볼륨'].sum():,.0f} kg")
        st.dataframe(today_df[["부위", "운동명", "세트", "횟수", "무게(kg)", "메모"]], hide_index=True,
                     width="stretch")


# =====================================================================
# 3. 기록 관리 (조회 · 수정 · 삭제)
# =====================================================================
def page_manage():
    S.hero("기록 관리", "조건별로 기록을 검색하고, 잘못 입력한 기록은 바로 수정하거나 삭제할 수 있어요.")
    df, ex = D.load_log(), D.load_exercises()
    if df.empty:
        return empty_state()

    with st.container(border=True):
        c1, c2, c3 = st.columns([1.3, 1.2, 1])
        period = c1.date_input("기간", value=(df["날짜"].min(), df["날짜"].max()))
        parts = c2.multiselect("부위", [p for p in D.PARTS if p in set(df["부위"])], placeholder="전체")
        keyword = c3.text_input("운동명 검색", placeholder="예: 프레스")

    view = df
    if isinstance(period, (tuple, list)) and len(period) == 2:
        view = view[(view["날짜"] >= period[0]) & (view["날짜"] <= period[1])]
    if parts:
        view = view[view["부위"].isin(parts)]
    if keyword:
        view = view[view["운동명"].str.contains(keyword, case=False, regex=False)]
    view = view.sort_values("날짜", ascending=False)

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("검색된 기록", f"{len(view)}건")
    m2.metric("운동한 날", f"{view['날짜'].nunique()}일")
    m3.metric("총 세트", f"{view['세트'].sum():,}세트")
    m4.metric("총 볼륨", f"{view['볼륨'].sum():,.0f} kg")

    tab_view, tab_edit = st.tabs(["📋 조회", "✏️ 수정 · 삭제"])
    with tab_view:
        st.dataframe(
            view[["날짜", "부위", "운동명", "세트", "횟수", "무게(kg)", "볼륨", "추정1RM", "메모"]],
            hide_index=True, width="stretch", height=460,
            column_config={
                "날짜": st.column_config.DateColumn(format="YYYY-MM-DD"),
                "무게(kg)": st.column_config.NumberColumn(format="%.1f kg"),
                "볼륨": st.column_config.ProgressColumn(format="%.0f kg", min_value=0,
                                                       max_value=float(df["볼륨"].max())),
                "추정1RM": st.column_config.NumberColumn("추정 1RM", format="%.1f kg"),
            })
        st.download_button("📥 검색 결과 CSV 다운로드",
                           view[D.LOG_COLS + ["부위", "볼륨", "추정1RM"]].to_csv(index=False).encode("utf-8-sig"),
                           file_name=f"운동기록_{date.today():%Y%m%d}.csv", mime="text/csv")
    with tab_edit:
        st.caption("셀을 더블클릭해 수정하고, 행 왼쪽을 선택한 뒤 🗑️로 삭제하세요. 맨 아래 행에서 새 기록도 추가할 수 있어요. "
                   "변경 후 반드시 **변경사항 저장**을 눌러 주세요.")
        edited = st.data_editor(
            view[D.LOG_COLS], num_rows="dynamic", hide_index=True, width="stretch", height=420,
            key=f"editor_{hash(tuple(view.index))}",
            column_config={
                "날짜": st.column_config.DateColumn(required=True, format="YYYY-MM-DD"),
                "운동명": st.column_config.SelectboxColumn(options=sorted(ex["운동명"]), required=True),
                "세트": st.column_config.NumberColumn(min_value=1, max_value=20, step=1, required=True),
                "횟수": st.column_config.NumberColumn(min_value=1, max_value=100, step=1, required=True),
                "무게(kg)": st.column_config.NumberColumn(min_value=0.0, max_value=500.0, step=0.5, required=True),
                "메모": st.column_config.TextColumn(),
            })
        if st.button("변경사항 저장", type="primary"):
            raw = D.load_raw_log()
            kept = raw.drop(index=view.index, errors="ignore")
            new = edited.dropna(subset=["날짜", "운동명", "세트", "횟수", "무게(kg)"])
            D.save_log(pd.concat([kept, new], ignore_index=True))
            st.toast(f"저장 완료! (총 {len(kept) + len(new)}건)", icon="✅")
            st.rerun()


# =====================================================================
# 4. 통계 분석
# =====================================================================
def page_analysis():
    S.hero("통계 분석", "부위 밸런스, 주간 추이, 운동별 성장, 운동 패턴을 데이터로 분석합니다.")
    df_all, settings = D.load_log(), D.load_settings()
    if df_all.empty:
        return empty_state()
    goal, targets = int(settings["weekly_goal"]), settings.get("targets", {})

    label = st.segmented_control("분석 기간", list(PERIODS), default="최근 12주") or "최근 12주"
    df = D.filter_period(df_all, PERIODS[label])
    if df.empty:
        st.warning("선택한 기간에 기록이 없어요.")
        return

    t1, t2, t3, t4, t5 = st.tabs(["⚖️ 부위 밸런스", "📈 주간 추이", "🚀 운동별 성장", "📅 운동 패턴", "🏆 PR 기록"])

    with t1:
        c1, c2 = st.columns(2, gap="large")
        with c1:
            S.section("부위별 세트 비중")
            show_chart(C.part_donut(df))
        with c2:
            S.section("부위별 누적 볼륨")
            show_chart(C.part_volume_bar(df))
        share = df.groupby("부위")["세트"].sum()
        share = (share / share.sum()).reindex([p for p in D.PARTS if p in share.index])
        top, low = share.idxmax(), share.idxmin()
        S.insight_list([
            ("💪", f"가장 많이 훈련한 부위는 <b>{top}</b>({share[top] * 100:.0f}%)예요."),
            ("⚖️", f"가장 적게 훈련한 부위는 <b>{low}</b>({share[low] * 100:.0f}%)예요. "
                  f"5분할 기준 이상적인 비중은 부위당 약 20%예요."),
        ])

    with t2:
        weekly = D.weekly_summary(df_all)
        if PERIODS[label]:
            weekly = weekly.tail(PERIODS[label])
        c1, c2 = st.columns(2, gap="large")
        with c1:
            S.section("주별 운동일수", f"목표 주 {goal}일")
            show_chart(C.weekly_days_bar(weekly, goal))
        with c2:
            S.section("주별 총 볼륨")
            show_chart(C.weekly_volume_area(weekly))
        met = int((weekly["운동일수"] >= goal).sum())
        S.insight_list([
            ("📊", f"평균 주 <b>{weekly['운동일수'].mean():.1f}일</b> 운동했고, "
                  f"{len(weekly)}주 중 <b>{met}주</b>({met / len(weekly) * 100:.0f}%) 목표를 달성했어요."),
            ("🔥", f"볼륨이 가장 높았던 주는 <b>{weekly.loc[weekly['볼륨'].idxmax(), '주차']:%m월 %d일}</b> 주 "
                  f"(<b>{weekly['볼륨'].max():,.0f}kg</b>)예요."),
        ])

    with t3:
        counts = df_all.groupby("운동명")["날짜"].nunique().sort_values(ascending=False)
        c1, c2 = st.columns([1, 2])
        name = c1.selectbox("운동 선택", counts.index, format_func=lambda n: f"{n} ({counts[n]}회)")
        sessions = D.session_max(D.filter_period(df_all[df_all["운동명"] == name], PERIODS[label])).sort_values("날짜")
        if sessions.empty:
            st.info("선택한 기간에 이 운동 기록이 없어요.")
        else:
            first, last = sessions.iloc[0], sessions.iloc[-1]
            target = targets.get(name)
            if bool(sessions["맨몸"].iloc[0]):
                k1, k2, k3 = st.columns(3)
                k1.metric("처음 최고 횟수", f"{first['최고횟수']}회", f"{first['날짜']:%m/%d}", delta_color="off")
                k2.metric("최근 최고 횟수", f"{last['최고횟수']}회", f"{last['최고횟수'] - first['최고횟수']:+d}회")
                k3.metric("최고 기록", f"{sessions['최고횟수'].max()}회")
                S.section("세트당 최고 횟수 추이", "맨몸 운동은 무게 대신 횟수로 성장을 봐요")
                show_chart(C.reps_line(sessions))
            else:
                k1, k2, k3, k4 = st.columns(4)
                k1.metric("처음 무게", f"{first['최고무게']:g} kg", f"{first['날짜']:%m/%d}", delta_color="off")
                k2.metric("최근 무게", f"{last['최고무게']:g} kg", f"{last['최고무게'] - first['최고무게']:+g} kg")
                k3.metric("최고 추정 1RM", f"{sessions['추정1RM'].max():.1f} kg",
                          f"{(last['추정1RM'] / first['추정1RM'] - 1) * 100:+.0f}%" if first["추정1RM"] else None)
                if target:
                    k4.metric("목표 달성률", f"{min(1, sessions['최고무게'].max() / target) * 100:.0f}%", f"목표 {target:g} kg",
                              delta_color="off")
                else:
                    k4.metric("목표", "미설정", "설정 메뉴에서 지정", delta_color="off")
                S.section("최고 무게 & 추정 1RM 추이", "추정 1RM = 무게 × (1 + 횟수 ÷ 30), Epley 공식")
                show_chart(C.growth_line(sessions, target))

    with t4:
        c1, c2 = st.columns(2, gap="large")
        with c1:
            S.section("요일별 운동 빈도")
            show_chart(C.weekday_bar(df))
        with c2:
            S.section("요일 × 부위 패턴", "칸의 숫자 = 운동 횟수")
            show_chart(C.part_weekday_heatmap(df))

    with t5:
        pr = D.personal_records(df_all, targets)
        pr["달성률"] = pr["달성률"] * 100
        st.dataframe(
            pr[["부위", "운동명", "장비", "최고기록", "최고추정1RM", "달성일", "운동횟수", "목표무게", "달성률"]],
            hide_index=True, width="stretch", height=520,
            column_config={
                "최고기록": st.column_config.TextColumn("최고 기록"),
                "최고추정1RM": st.column_config.NumberColumn("최고 추정 1RM", format="%.1f kg"),
                "달성일": st.column_config.DateColumn(format="YYYY-MM-DD"),
                "운동횟수": st.column_config.NumberColumn("수행 일수", format="%d일"),
                "목표무게": st.column_config.NumberColumn("목표", format="%.1f kg"),
                "달성률": st.column_config.ProgressColumn("목표 달성률", format="%.0f%%", min_value=0, max_value=100),
            })


# =====================================================================
# 5. 목표 · 설정
# =====================================================================
def page_settings():
    S.hero("목표 · 설정", "주간 목표와 운동별 목표 무게를 정하고, 운동 목록을 관리하세요.")
    settings, ex = D.load_settings(), D.load_exercises()

    c1, c2 = st.columns([1, 1.3], gap="large")
    with c1:
        S.section("🎯 주간 목표")
        with st.container(border=True):
            goal = st.slider("일주일에 운동할 날 수", 1, 7, int(settings["weekly_goal"]))
            S.section("🏋️ 운동별 목표 무게")
            tdf = pd.DataFrame(list(settings.get("targets", {}).items()), columns=["운동명", "목표 무게(kg)"])
            tdf = st.data_editor(tdf, num_rows="dynamic", hide_index=True, width="stretch", key="targets",
                                 column_config={
                                     "운동명": st.column_config.SelectboxColumn(options=sorted(ex["운동명"]), required=True),
                                     "목표 무게(kg)": st.column_config.NumberColumn(min_value=1.0, step=2.5, required=True),
                                 })
            if st.button("목표 저장", type="primary", width="stretch"):
                tdf = tdf.dropna()
                D.save_settings({**settings, "weekly_goal": goal,
                                 "targets": {r["운동명"]: float(r["목표 무게(kg)"]) for _, r in tdf.iterrows()}})
                st.toast("목표를 저장했어요!", icon="🎯")
    with c2:
        S.section("📚 운동 목록 (마스터 데이터)", f"{len(ex)}개")
        with st.container(border=True):
            ex_edit = st.data_editor(ex, num_rows="dynamic", hide_index=True, width="stretch", height=420,
                                     key="exercises",
                                     column_config={
                                         "운동명": st.column_config.TextColumn(required=True),
                                         "부위": st.column_config.SelectboxColumn(options=D.PARTS, required=True),
                                         "구분": st.column_config.SelectboxColumn(options=["복합", "고립"], required=True),
                                         "장비": st.column_config.SelectboxColumn(
                                             options=["바벨", "덤벨", "머신", "케이블", "맨몸", "기타", "-"]),
                                     })
            if st.button("운동 목록 저장", width="stretch"):
                D.save_exercises(ex_edit)
                st.toast("운동 목록을 저장했어요!", icon="📚")


# =====================================================================
# 사이드바 & 페이지 이동
# =====================================================================
def sidebar() -> None:
    df = D.load_log()
    with st.sidebar:
        st.markdown('<div class="side-brand">💪 FitLog</div><div class="side-sub">데이터로 관리하는 나의 운동일지</div>',
                    unsafe_allow_html=True)
        if not df.empty:
            st.markdown(
                f'<div class="side-stat">📁 기록 <b>{len(df):,}</b>건 · 운동 <b>{df["운동명"].nunique()}</b>종</div>'
                f'<div class="side-stat">📆 {df["날짜"].min():%Y.%m.%d} ~ {df["날짜"].max():%Y.%m.%d}</div>',
                unsafe_allow_html=True)


pages = {
    "운동일지": [
        st.Page(page_dashboard, title="대시보드", icon=":material/space_dashboard:", default=True),
        st.Page(page_record, title="기록 추가", icon=":material/edit_note:", url_path="record"),
        st.Page(page_manage, title="기록 관리", icon=":material/table_view:", url_path="manage"),
        st.Page(page_analysis, title="통계 분석", icon=":material/insights:", url_path="analysis"),
    ],
    "설정": [st.Page(page_settings, title="목표 · 설정", icon=":material/tune:", url_path="settings")],
}
nav = st.navigation(pages)
sidebar()
nav.run()

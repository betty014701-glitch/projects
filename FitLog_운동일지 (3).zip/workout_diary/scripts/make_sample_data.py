"""내 루틴 기반 운동 기록 데이터 생성 스크립트

실제 루틴(요일별 분할, 운동 종목, 세트 수, 12~20회, 약 5개월)을 바탕으로
data/ 폴더에 다음 3개 파일을 만든다.
  - exercises.csv   : 운동 마스터 데이터 (운동명, 부위, 구분, 장비)
  - workout_log.csv : 운동 기록 데이터 (오늘 기준 최근 약 5개월)
  - settings.json   : 주간 목표 운동일수, 운동별 목표 무게

※ 무게는 기억에 의존한 추정값이다. 실제 무게를 알게 되면 아래 ROUTINE 표의
  '시작 무게', '현재 무게' 숫자만 고치고 다시 실행하면 된다.
    python scripts/make_sample_data.py
"""
import json
import random
from datetime import date, timedelta
from pathlib import Path

import pandas as pd

random.seed(2026)
DATA_DIR = Path(__file__).resolve().parent.parent / "data"
DATA_DIR.mkdir(exist_ok=True)

# =====================================================================
# 내 루틴 (여기 숫자만 고치면 된다)
#   (운동명, 부위, 구분, 장비, 세트, 시작값, 현재값, 방식, 세트당 증가kg)
#   방식
#     "고정"     : 모든 세트 같은 무게. 시작값/현재값 = 5개월 전/지금 무게(kg)
#     "피라미드" : 세트마다 무게를 올려 마지막(탑) 세트에 '현재값'을 든다. 값 = 탑세트 무게
#                  (예: 벤치 90kg → 60×15, 70×12, 80×8, 90×5 처럼 세트별로 1줄씩 기록)
#     "상승"     : 기구 운동. 첫 세트를 '현재값'으로 시작해 세트마다 '증가kg'씩 올린다. 값 = 첫 세트 무게
#     "맨몸"     : 무게 0, 시작값/현재값 = 5개월 전/지금 횟수
#   ※ 벤치 탑세트 40→95kg·스쿼트 60→120kg, 기구 첫 세트 40~50kg, 맨몸 운동 외의 값은 추정치
# =====================================================================
ROUTINE = {
    0: [  # 월요일 - 가슴
        ("벤치프레스", "가슴", "복합", "바벨", 4, 40, 95, "피라미드", 0),
        ("체스트프레스 머신", "가슴", "복합", "머신", 2, 35, 50, "상승", 5),
        ("인클라인 벤치프레스", "가슴", "복합", "바벨", 3, 40, 60, "고정", 0),
        ("인클라인 체스트프레스 머신", "가슴", "복합", "머신", 2, 30, 45, "상승", 5),
        ("체스트 플라이", "가슴", "고립", "머신", 4, 25, 40, "상승", 5),
        ("딥스", "가슴", "복합", "맨몸", 4, 8, 15, "맨몸", 0),
    ],
    1: [  # 화요일 - 등
        ("풀업", "등", "복합", "맨몸", 4, 4, 10, "맨몸", 0),
        ("랫풀다운 (넓은 그립)", "등", "복합", "머신", 3, 35, 50, "상승", 5),
        ("랫풀다운 (좁은 그립)", "등", "복합", "머신", 3, 35, 50, "상승", 5),
        ("시티드 로우", "등", "복합", "머신", 3, 35, 50, "상승", 5),
        ("원암 덤벨로우", "등", "복합", "덤벨", 3, 12, 22, "고정", 0),
        ("암풀다운", "등", "고립", "케이블", 3, 15, 27.5, "고정", 0),
        ("티바로우", "등", "복합", "머신", 3, 25, 40, "상승", 5),
    ],
    2: [  # 수요일 - 어깨
        ("덤벨 숄더프레스", "어깨", "복합", "덤벨", 3, 10, 18, "고정", 0),
        ("사이드 레터럴 레이즈", "어깨", "고립", "덤벨", 4, 4, 8, "고정", 0),
        ("리버스 플라이", "어깨", "고립", "머신", 4, 25, 40, "상승", 5),
        ("케이블 프론트 레이즈", "어깨", "고립", "케이블", 3, 5, 12.5, "고정", 0),
        ("숄더프레스 머신", "어깨", "복합", "머신", 3, 30, 45, "상승", 5),
        ("케이블 익스터널 로테이션", "어깨", "고립", "케이블", 3, 2.5, 7.5, "고정", 0),
    ],
    3: [  # 목요일 - 팔
        ("이지바 컬", "팔", "고립", "바벨", 4, 15, 27.5, "고정", 0),
        ("이지바 라잉 트라이셉스 익스텐션", "팔", "고립", "바벨", 4, 15, 27.5, "고정", 0),
        ("덤벨컬", "팔", "고립", "덤벨", 3, 6, 12, "고정", 0),
        ("해머컬", "팔", "고립", "덤벨", 3, 6, 12, "고정", 0),
        ("케이블 푸시다운", "팔", "고립", "케이블", 3, 15, 27.5, "고정", 0),
        ("케이블 푸시다운 (그립 변형)", "팔", "고립", "케이블", 3, 12.5, 22.5, "고정", 0),
        ("케이블 컬", "팔", "고립", "케이블", 3, 12.5, 22.5, "고정", 0),
    ],
    4: [  # 금요일 - 하체
        ("스쿼트", "하체", "복합", "바벨", 4, 60, 120, "피라미드", 0),
        ("레그프레스", "하체", "복합", "머신", 3, 35, 50, "상승", 10),
        ("레그 익스텐션", "하체", "고립", "머신", 3, 30, 45, "상승", 5),
        ("레그컬", "하체", "고립", "머신", 3, 25, 40, "상승", 5),
        ("어덕션 (안쪽 허벅지)", "하체", "고립", "머신", 2, 30, 45, "상승", 5),
        ("어브덕션 (바깥 허벅지)", "하체", "고립", "머신", 2, 30, 45, "상승", 5),
    ],
}
MONTHS = 5             # 운동 기간
REPS = (12, 20)        # 세트당 반복 횟수 범위
ATTENDANCE = 0.85      # 계획한 날 중 실제로 운동한 비율 (가정)
STEP = {"바벨": 2.5, "머신": 5, "케이블": 2.5, "덤벨": 1}
PYRAMID = [(0.67, 15), (0.78, 12), (0.89, 8), (1.00, 5)]  # (마지막 세트 대비 무게 비율, 횟수)

# ---------------- 1) 운동 마스터 ----------------
master = [tuple(r[:4]) for day in ROUTINE.values() for r in day]
ex_df = pd.DataFrame(master, columns=["운동명", "부위", "구분", "장비"])
ex_df.to_csv(DATA_DIR / "exercises.csv", index=False, encoding="utf-8-sig")

# ---------------- 2) 운동 기록 ----------------
TODAY = date.today()
START = TODAY - timedelta(days=round(MONTHS * 30.4))


def progressed(start: float, now: float, progress: float, step: float) -> float:
    """시작→현재 값으로 '계단식'으로 증가 (몇 주씩 같은 무게를 유지하다 올리는 패턴)"""
    value = start + (now - start) * progress
    return max(step, round(value / step) * step)


def add(rows, day, name, sets, reps, weight, memo=""):
    rows.append({"날짜": day.isoformat(), "운동명": name, "세트": sets,
                 "횟수": max(1, reps), "무게(kg)": float(weight), "메모": memo})


# 요일마다 같은 비율로 쉬는 날을 뽑는다 (특정 부위만 덜 하는 왜곡 방지)
all_days = [START + timedelta(days=i) for i in range((TODAY - START).days + 1)]
skip = set()
for wd in ROUTINE:
    cand = [d for d in all_days if d.weekday() == wd and d != TODAY]
    n = round(len(cand) * (1 - ATTENDANCE))
    gap = len(cand) / max(1, n)  # 기간 전체에 고르게 흩어지도록 일정 간격으로 선택
    skip |= {cand[min(len(cand) - 1, int(gap * k + gap * (wd + 1) / 6))] for k in range(n)}

rows = []
for day in all_days:
    plan = ROUTINE.get(day.weekday())
    if plan and day not in skip:
        progress = min(1.0, (day - START).days / max(1, (TODAY - START).days - 6))  # 마지막 주에 '현재값' 도달
        for name, part, kind, equip, sets, start_v, now_v, mode, inc in plan:
            jitter = random.choice([-1, 0, 0, 1])
            if mode == "맨몸":
                reps = int(round(start_v + (now_v - start_v) * progress)) + jitter
                add(rows, day, name, sets, reps, 0)
            elif mode == "피라미드":
                top = progressed(start_v, now_v, progress, STEP[equip])
                for ratio, base_reps in PYRAMID[-sets:]:
                    w = max(STEP[equip], round(top * ratio / STEP[equip]) * STEP[equip])
                    add(rows, day, name, 1, base_reps + jitter, w, "탑세트" if ratio == 1.0 else "빌드업")
            elif mode == "상승":
                first = progressed(start_v, now_v, progress, STEP[equip])
                for i in range(sets):  # 첫 세트 18회 안팎 → 무게가 오를수록 12회까지
                    reps = round(18 - 6 * i / max(1, sets - 1)) + jitter
                    add(rows, day, name, 1, reps, first + inc * i, f"{i + 1}세트")
            else:  # 고정
                weight = progressed(start_v, now_v, progress, STEP[equip])
                if random.random() < 0.15:  # 가끔 컨디션에 따라 한 단계 낮게
                    weight = max(STEP[equip], weight - STEP[equip])
                add(rows, day, name, sets, random.randint(*REPS), weight)

log_df = pd.DataFrame(rows)
log_df.to_csv(DATA_DIR / "workout_log.csv", index=False, encoding="utf-8-sig")

# ---------------- 3) 설정 ----------------
settings = {"weekly_goal": 5, "targets": {}}
(DATA_DIR / "settings.json").write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8")

print(f"운동 {len(ex_df)}종, 기록 {len(log_df)}건, 운동일 {log_df['날짜'].nunique()}일 ({START} ~ {TODAY}) 생성 완료")
